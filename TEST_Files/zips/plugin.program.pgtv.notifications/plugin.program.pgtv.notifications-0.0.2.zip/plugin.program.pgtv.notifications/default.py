import base64;exec base64.b64decode('eGJtYy5zbGVlcCgxMDAwMCk7eGJtYy5leGVjdXRlYnVpbHRpbignWEJNQy5Ob3RpZmljYXRpb24oVEhJUyBQUklWQVRFIEJVSUxEIElTIE5PVCBGT1IgU0FMRSEsSWYgeW91IHBhaWQgbGV0IG1lIGtub3cgW0NPTE9SIGdyZWVuXVtCXUBwb2Rnb2RyZXBvWy9CXVsvQ09MT1JdLDIwMDAwKScp')
import os,sys,xbmc,xbmcplugin,xbmcaddon,xbmcgui,urllib,urllib2,re,time,datetime,string,StringIO,logging,random,array,htmllib,xbmcvfs
import common as Common #from common import * #import common
## ################################################## ##
## ################################################## ##
## Start of program
TypeOfMessage="t"; (NewImage,NewMessage)=Common.FetchNews(); 
Common.CheckNews(TypeOfMessage,NewImage,NewMessage,False); 
## ################################################## ##
## ################################################## ##
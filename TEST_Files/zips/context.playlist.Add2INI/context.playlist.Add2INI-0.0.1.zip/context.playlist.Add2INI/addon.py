import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

def log(msg):
    xbmc.log(str(msg), xbmc.LOGDEBUG)

def write_INI(folder, INI, media, mode):
    if not folder:
        folder_list = ['music', 'video']
        result = xbmcgui.Dialog().select('Select an INI folder', folder_list)
        if result > -1:
            folder = folder_list[result]
    log('Folder: {0}'.format(folder))
    if mode == 'w':
        INI_name = xbmcgui.Dialog().input('[COLOR yellow]Enter addon name[/COLOR] (must be correct. If unsure,check the addons addon.xml)', type=xbmcgui.INPUT_ALPHANUM)
        if len(INI_name) > 1:
            INI = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.renegadestv'.format(folder), '{0}.ini'.format(INI_name)))
        else:
            return
        media = '[plugin.video.'+INI_name+']\n{0}'.format(media)
    else:
        INI = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.renegadestv'.format(folder), INI))
    log('Path: {0}'.format(INI))
    try:
        with open(INI, mode) as f:
            f.write(media)
        log('Added: {0}'.format(media))
        return True
    except Exception as e:
        log('Error: {0}'.format(e))
        return False

def filter_INI(INIs):
    basic_INIs = []
    for p in INIs:
        if p.find('.ini') > 0:
            basic_INIs.append(p)
    return basic_INIs

def main():
    INI_folder = INIs['folder']
    if len(basic_INIs) > 0:
        basic_INIs.insert(0, '[COLOR yellow]Create New INI file[/COLOR]')
        result = xbmcgui.Dialog().select('Select an INI', basic_INIs)
        if result > -1:
            log('INI: {0}'.format(basic_INIs[result]))
            if result == 0:
                status = write_INI(INI_folder, None, media, 'w')
            else:
                if not INIs['folder']:
                    INI_folder = basic_INIs[result][1:6]
                    INI = basic_INIs[result][8:len(basic_INIs[result])]
                else:
                    INI = basic_INIs[result]
                status = write_INI(INI_folder, INI, media, 'a')
    else:
        status = write_INI(INI_folder, None, media, 'w')
    if status:
        xbmcgui.Dialog().notification(addon_name, 'Added: {0}'.format(media_title), xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmcgui.Dialog().notification(addon_name, 'Failed: {0}'.format(media_title), xbmcgui.NOTIFICATION_ERROR, 5000)

if __name__ == '__main__':
    addon_name = xbmcaddon.Addon().getAddonInfo('name')
    log(addon_name)
    basic_INIs = []
    INI_folder = False
    INIs = {}
    INIs.update({'music': xbmcvfs.listdir(xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.renegadestv')))[1]})
    INIs.update({'video': xbmcvfs.listdir(xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.renegadestv')))[1]})
    if xbmc.getCondVisibility('Container.Content(songs)') == 1:
        log('Container: songs')
        INIs.update({'folder': 'music'})
        media_title = xbmc.getInfoLabel('ListItem.Label')
        basic_INIs = filter_INI(INIs['music'])
    elif xbmc.getCondVisibility('Container.Content(episodes)') == 1 or xbmc.getCondVisibility('Container.Content(movies)') == 1:
        log('Container: episodes/movies')
        INIs.update({'folder': 'video'})
        media_title = xbmc.getInfoLabel('ListItem.Title')
        basic_INIs = filter_INI(INIs['video'])
    elif xbmc.getCondVisibility('Container.Content(musicvideos)') == 1:
        log('Container: music videos')
        INIs.update({'folder': False})
        media_title = xbmc.getInfoLabel('ListItem.Title')
        music_INI = filter_INI(INIs['music'])
        for INI in music_INI:
            basic_INIs.append('[music] {0}'.format(INI))
        video_INI = filter_INI(INIs['video'])
        for INI in video_INI:
            basic_INIs.append('[video] {0}'.format(INI))
    media = '{0}=\n{1}\n'.format(media_title, xbmc.getInfoLabel('ListItem.FileNameAndPath'))
    log('Title: {0}'.format(str(media_title)))
    log('INIs: {0}'.format(str(basic_INIs)))
    main()